//
//  ColorDataSource.swift
//  CollectionLayout
//
//  Created by Kinjal Gadhia on 04/03/2022.
//  Copyright © 2022 Kinjal Gadhia. All rights reserved.
//

import Foundation
import UIKit

class GenericDataSource<T> : NSObject {
    var data = [Cusine]()
}

class ColorDataSource : GenericDataSource<UIColor>, UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DataCell", for: indexPath) as! DataCell
    
        cell.lblName.text = data[indexPath.row].strDrink
        cell.imgThumb.downloaded(from:data[indexPath.row].strDrinkThumb)
        cell.imgThumb.layer.cornerRadius = 12.0
        return cell
    }
}

