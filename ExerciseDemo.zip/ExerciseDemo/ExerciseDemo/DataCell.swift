//
//  CollectionViewCell.swift
//  CollectionLayout
//
//  Created by Kinjal Gadhia on 04/03/2022.
//  Copyright © 2022 Kinjal Gadhia. All rights reserved.
//

import UIKit

class DataCell: UICollectionViewCell {
    @IBOutlet weak var viewback: UIView!
    @IBOutlet weak var imgThumb: UIImageView!{
        didSet{
            imgThumb.layer.cornerRadius = 12.0
            imgThumb.layer.masksToBounds = true
            
        }
    }
    @IBOutlet weak var lblName: UILabel!
}
