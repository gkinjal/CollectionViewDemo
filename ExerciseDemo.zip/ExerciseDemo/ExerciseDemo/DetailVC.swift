//
//  DetailVC.swift
//  CollectionLayout
//
//  Created by Kinjal Gadhia on 04/03/2022.
//  Copyright © 2022 Kinjal Gadhia. All rights reserved.
//

import UIKit

class DetailVC: UIViewController {
    @IBOutlet weak var lblInstructions: UILabel!
    @IBOutlet weak var imgDrink: UIImageView!
    @IBOutlet weak var lblIngredients: UILabel!
    @IBOutlet weak var lblMeasure: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var lblCategory: UILabel!
    
    var drinkDetail = Cusine(dictionary: [:])
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblTitle.text = drinkDetail.strDrink
        imgDrink.downloaded(from: drinkDetail.strDrinkThumb)
        lblMeasure.text = drinkDetail.strMeasure1
        lblCategory.text = drinkDetail.strCategory
        
        lblIngredients.text = "\(drinkDetail.strIngredient1)\n\(drinkDetail.strIngredient2)\(drinkDetail.strIngredient3)\n\(drinkDetail.strIngredient4)\n\(drinkDetail.strIngredient5)\n\(drinkDetail.strIngredient6)\n"
        
        
        lblInstructions.text = drinkDetail.strInstructions
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
