//
//  Cusine.swift
//  CollectionLayout
//
//  Created by Kinjal Gadhia on 04/03/2022.
//  Copyright © 2022 Kinjal Gadhia. All rights reserved.
//

import Foundation

class Cusine:NSObject {
    
    var strDrink : String
    var strDrinkThumb : String
    var strCategory : String
    var strInstructions : String
    var strMeasure1 : String
    var strIngredient1 : String
    var strIngredient2 : String
    var strIngredient3 : String
    var strIngredient4 : String
    var strIngredient5 : String
    var strIngredient6 : String
    
    init(dictionary: [String:Any]) {
       
        strDrink = dictionary["strDrink"] as? String ?? ""
        strDrinkThumb = dictionary["strDrinkThumb"] as? String ?? ""
        strCategory = dictionary["strCategory"] as? String ?? ""
        strInstructions = dictionary["strInstructions"] as? String ?? ""
        strMeasure1 = dictionary["strMeasure1"] as? String ?? ""
        strIngredient1 = dictionary["strIngredient1"] as? String ?? ""
        strIngredient2 = dictionary["strIngredient2"] as? String ?? ""
        strIngredient3 = dictionary["strIngredient3"] as? String ?? ""
        strIngredient4 = dictionary["strIngredient4"] as? String ?? ""
        strIngredient5 = dictionary["strIngredient5"] as? String ?? ""
        strIngredient6 = dictionary["strIngredient6"] as? String ?? ""
        
        
    }
    
    func dictionaryRepresentation() -> [String:Any] {
        var dictionary:dictionary = [:]
        dictionary["strDrink"] = self.strDrink
        dictionary["strDrinkThumb"] = self.strDrinkThumb
        dictionary["strCategory"] = self.strCategory
        dictionary["strInstructions"] = self.strInstructions
        dictionary["strMeasure1"] = self.strMeasure1
        dictionary["strIngredient1"] = self.strIngredient1
        dictionary["strIngredient2"] = self.strIngredient2
        dictionary["strIngredient3"] = self.strIngredient3
        dictionary["strIngredient4"] = self.strIngredient4
        dictionary["strIngredient5"] = self.strIngredient5
        dictionary["strIngredient6"] = self.strIngredient6
        
        return dictionary
    }
    
}
