//
//  Helper Class.swift
//  CollectionLayout
//
//  Created by Kinjal Gadhia on 04/03/2022.
//  Copyright © 2022 Kinjal Gadhia. All rights reserved.
//
import Foundation
import UIKit

struct ResponseHandler{
    private init() { }
    
    static func fatchDataAsDictionary(res: dictionary, valueOf key: keys) -> [String:Any] {
        if res[key.rawValue] as? [String:Any] != nil{
            //print("Dictionary as a response")
            return res[key.rawValue] as! [String:Any]
        }
        else{
            if res[key.rawValue] as? [Any] != nil{
                print("Response is different: Array as a response")
                return [:]
            }
            else if res[key.rawValue] as? String != nil{
                print("Response is different: String as a response")
                return [:]
            }else{
                print("Response is different: Response type not a Dictionary nore Array or String")
                return [:]
            }
        }
    }
    
    static func fatchDataAsArray(res: dictionary, valueOf key: keys) -> [Any] {
        if res[key.rawValue] as? [Any] != nil{
            //print("Array as a response")
            return res[key.rawValue] as! [Any]
        }
        else{
            if res[key.rawValue] as? [String:Any] != nil{
                print("Response is different: Dictionary as a response")
                return []
            }
            else if res[key.rawValue] as? String != nil{
                print("Response is different: String as a response")
                return []
            }else{
                print("Response is different: Response type not a Dictionary nore Array or String")
                return []
            }
        }
    }
    
    static func fatchDataAsString(res: dictionary, valueOf key: keys) -> String {
        if res[key.rawValue] as? String != nil{
            //print("String as a response")
            return res[key.rawValue] as! String
        }
        else{
            if res[key.rawValue] as? [Any] != nil{
                print("Response is different: Array as a response")
                return ""
            }
            else if res[key.rawValue] as? [String:Any] != nil{
                print("Response is different: Dictionary as a response")
                return ""
            }else{
                print("Response is different: Response type not a Dictionary nore Array or String")
                return ""
            }
        }
    }
    
    static func fatchData(res: dictionary, valueOf key: keys) -> (dic: [String:Any], ary: [Any], str: String){
        if res[key.rawValue] as? [String:Any] != nil{
            print("Dictionary as a response")
            return (dic: res[key.rawValue] as! [String:Any], ary: [], str: "")
        }
        else if res[key.rawValue] as? [Any] != nil{
            print("Array as a response")
            return (dic: [:], ary: res[key.rawValue] as! [Any], str: "")
        }
        else if res[key.rawValue] as? String != nil{
            print("String as a response")
            return (dic: [:], ary: [], str: res[key.rawValue] as! String)
        }else{
            print("Response type not a Dictionary nore Array or String")
            return (dic: [:], ary:[], str: "")
        }
    }
    
    
}
typealias dictionary = [String:Any]

enum DispatchMode{
    case background
    case `default`
    
    var type:DispatchQueue{
        switch self {
        case .background:
            return DispatchQueue.background
        case .default:
            return DispatchQueue.default
        }
    }
    
}
enum keys:String  {
    case status = "status"
    case message = "message"
    case data = "data"
    case drinks = "drinks"
    case statusCode = "status_code"
    case getContactListNameDetails = "getContactListNameDetails"
    case authToken = "auth_token"
    
    //case
    //
    case ticketsArray = "ticketsArray"
    case organizersArray = "organizersArray"
    case is_user_like = "is_user_like"
    case is_user_follow = "is_user_follow"
    case getAllBackImages = "getAllBackImages"
}
extension DispatchQueue{
    static var background:DispatchQueue {
        let queue = DispatchQueue(label: Bundle.main.bundleIdentifier ?? "com.app.test", qos: .background, attributes: .concurrent)
        return queue
    }
    static var `default`:DispatchQueue {
        //let queue = DispatchQueue(label: Bundle.main.bundleIdentifier ?? "com.app.test", qos: .default, attributes: .concurrent)
        let queue = DispatchQueue(label: Bundle.main.bundleIdentifier ?? "com.app.test", qos: .default, attributes: .concurrent)
        return queue
    }
}
extension UIView {

    func dropShadow() {
        layer.masksToBounds = false
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.5
        layer.shadowOffset = CGSize(width: -1, height: 1)
        layer.shadowRadius = 1
        layer.shadowPath = UIBezierPath(rect: self.bounds).cgPath
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
    }
}
extension UIImageView {
    func downloaded(from url: URL, contentMode mode: ContentMode = .scaleAspectFit) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() { [weak self] in
                self?.image = image
            }
        }.resume()
    }
    func downloaded(from link: String, contentMode mode: ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
}
