//
//  ViewController.swift
//  CollectionLayout
//
//  Created by Kinjal Gadhia on 04/03/2022.
//  Copyright © 2022 Kinjal Gadhia. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController {
    
    @IBOutlet weak var txtSearch: UITextField!{
        didSet{
            txtSearch.delegate = self
        }
    }
    var search:String=""
    @IBOutlet weak var imgHotel: UIImageView!{
        didSet{
            imgHotel.layer.cornerRadius = 10.0
        }
    }
    @IBOutlet weak var viewMain: UIView!{
        didSet{
            viewMain.dropShadow()
            viewMain.layer.cornerRadius = 10.0
            viewMain.layer.masksToBounds = true
            
        }
    }
    @IBOutlet weak var collectionView : UICollectionView!{
        didSet{
        collectionView.delegate = self
        }
    }
    
    lazy var collectionViewFlowLayout : CustomCollectionViewFlowLayout = {
        let layout = CustomCollectionViewFlowLayout(display: .grid)
        return layout
    }()
    
    var dataSource = ColorDataSource()
    var listCusines:[Cusine] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.collectionView.collectionViewLayout = self.collectionViewFlowLayout
        self.collectionView.dataSource = self.dataSource
        callAPI(strSearch: "")
//        self.dataSource.data.addAndNotify(observer: self) { [weak self] in
//            self?.collectionView.reloadData()
//        }
        
        
        
        
    }

    func callAPI(strSearch:String){
        let url = URL(string: "http://thecocktaildb.com/api/json/v1/1/search.php?s=\(strSearch)")!
        Alamofire.request(url, method: .get, parameters: [:], encoding: URLEncoding.httpBody)
                .responseJSON{ response in

                    let swiftyJsonVar = JSON(response.result.value!)
                    if let resData = swiftyJsonVar.dictionaryObject
                                    {
                self.listCusines = ResponseHandler.fatchDataAsArray(res: resData, valueOf: .drinks).map({Cusine(dictionary: $0 as! [String : Any])})
                        print(self.listCusines)
                        DispatchQueue.main.async {
                        self.dataSource.data = self.listCusines
                        
                        self.collectionView.reloadData()
                        }
                    }
            }
    }
    
    @IBAction func layoutValueChanged(_ sender: UISegmentedControl) {
        
        switch sender.selectedSegmentIndex {
        case 1:
            self.collectionViewFlowLayout.display = .list
        case 2:
            self.collectionViewFlowLayout.display = .inline
        default:
            self.collectionViewFlowLayout.display = .grid
        }
    }
}


extension ViewController:UITextFieldDelegate{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        if string.isEmpty
        {
            search = String(search.dropLast())
        }
        else
        {
            search=textField.text!+string
        }

        print(search)
       callAPI(strSearch: search)
        return true
    }
}
extension ViewController:UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "DetailVC") as? DetailVC
        vc?.drinkDetail = listCusines[indexPath.row]
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}
