//
//  DynamicValue.swift
//  CollectionLayout
//
//  Created by Kinjal Gadhia on 04/03/2022.
//  Copyright © 2022 Kinjal Gadhia. All rights reserved.
//

import Foundation

typealias CompletionHandler = (() -> Void)
class DynamicValue<Cusine> {
    
    var value : Cusine {
        didSet {
            self.notify()
        }
    }
    
    private var observers = [String: CompletionHandler]()
    
    init(_ value: Cusine) {
        self.value = value
    }
    
    public func addObserver(_ observer: NSObject, completionHandler: @escaping CompletionHandler) {
        observers[observer.description] = completionHandler
    }
    
    public func addAndNotify(observer: NSObject, completionHandler: @escaping CompletionHandler) {
        self.addObserver(observer, completionHandler: completionHandler)
        self.notify()
    }
    
    private func notify() {
        observers.forEach({ $0.value() })
    }
    
    deinit {
        observers.removeAll()
    }
}
